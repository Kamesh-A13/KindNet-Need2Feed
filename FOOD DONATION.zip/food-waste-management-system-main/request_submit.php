<?php
session_start();
include "connection.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($connection, $_POST['requester_name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $phone = mysqli_real_escape_string($connection, $_POST['phone']);
    $type = mysqli_real_escape_string($connection, $_POST['type']);
    $desc = mysqli_real_escape_string($connection, $_POST['description']);
    $amount = !empty($_POST['amount_needed']) ? floatval($_POST['amount_needed']) : NULL;

    $sql = "INSERT INTO help_requests (requester_name, email, phone, type, description, amount_needed) 
            VALUES ('$name','$email','$phone','$type','$desc', ".($amount ?? 'NULL').")";

    if (mysqli_query($connection, $sql)) {
        echo "Request submitted successfully! Pending admin approval.";
        echo "<br><a href='request.php'>Submit another request</a>";
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}
?>
