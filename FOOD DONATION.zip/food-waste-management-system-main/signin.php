<?php
session_start();
include 'connection.php';
$msg = 0;

if (isset($_POST['sign'])) {
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);

    // Check user table
    $sql_user = "SELECT * FROM login WHERE email='$email'";
    $res_user = mysqli_query($connection, $sql_user);

    if (mysqli_num_rows($res_user) == 1) {
        $row = mysqli_fetch_assoc($res_user);
        if (password_verify($password, $row['password'])) {
            $_SESSION['email'] = $row['email'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['gender'] = $row['gender'];
            $_SESSION['role'] = 'user'; // user role
            header("Location: home.html");
            exit;
        } else {
            $msg = 1;
        }
    } else {
        // Check admin table
        $sql_admin = "SELECT * FROM admin WHERE email='$email'";
        $res_admin = mysqli_query($connection, $sql_admin);
        if (mysqli_num_rows($res_admin) == 1) {
            $row = mysqli_fetch_assoc($res_admin);
            if (password_verify($password, $row['password'])) {
                $_SESSION['email'] = $row['email'];
                $_SESSION['name'] = $row['name'];
                $_SESSION['role'] = 'admin'; // admin role
                header("Location: admin/dashboard.php"); // redirect admin
                exit;
            } else {
                $msg = 1;
            }
        } else {
            echo "<h1><center>Account does not exist</center></h1>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Donate Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,500;0,700;0,800;1,400;1,600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            overflow-x: hidden;
        }
        
        .container {
            display: flex;
            max-width: 1200px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 1s ease-out;
        }
        
        .regform {
            flex: 1;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }
        
        .illustration {
            flex: 1;
            background: linear-gradient(135deg, #06C167 0%, #059c54 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .illustration::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
            animation: float 20s infinite linear;
        }
        
        .illustration-content {
            z-index: 1;
            position: relative;
            animation: slideInRight 1s ease-out;
        }
        
        .illustration img {
            max-width: 80%;
            margin-bottom: 30px;
            animation: bounce 5s infinite ease-in-out;
        }
        
        .illustration h2 {
            font-size: 28px;
            margin-bottom: 15px;
        }
        
        .illustration p {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .logo {
            font-size: 36px;
            text-align: center;
            margin-bottom: 10px;
            animation: slideDown 0.8s ease-out;
        }
        
        .logo b {
            color: #06C167;
        }
        
        #heading {
            font-size: 28px;
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            animation: slideUp 0.8s ease-out 0.3s both;
        }
        
        .input, .password {
            margin-bottom: 20px;
            position: relative;
            animation: fadeIn 1s ease-out 0.5s both;
        }
        
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e1e1e1;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        input:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
            transform: translateY(-2px);
        }
        
        .password {
            position: relative;
        }
        
        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            transition: color 0.3s ease;
            z-index: 2;
        }
        
        .showHidePw:hover {
            color: #06C167;
        }
        
        .btn {
            margin-bottom: 20px;
            animation: fadeIn 1s ease-out 0.7s both;
        }
        
        button {
            width: 100%;
            padding: 15px;
            background: #06C167;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(6, 193, 103, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }
        
        button:hover {
            background: #059c54;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(6, 193, 103, 0.4);
        }
        
        button:hover::before {
            left: 100%;
        }
        
        .signin-up {
            text-align: center;
            animation: fadeIn 1s ease-out 0.9s both;
        }
        
        .signin-up a {
            color: #06C167;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .signin-up a:hover {
            text-decoration: underline;
            letter-spacing: 0.5px;
        }
        
        .error {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 5px;
            text-align: center;
            animation: shake 0.5s ease-in-out;
        }
        
        .floating-icons {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        
        .floating-icons i {
            position: absolute;
            color: rgba(6, 193, 103, 0.1);
            font-size: 24px;
            animation: float 15s infinite linear;
        }
        
        .floating-icons i:nth-child(1) {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }
        
        .floating-icons i:nth-child(2) {
            top: 20%;
            right: 15%;
            animation-delay: 2s;
        }
        
        .floating-icons i:nth-child(3) {
            bottom: 30%;
            left: 15%;
            animation-delay: 4s;
        }
        
        .floating-icons i:nth-child(4) {
            bottom: 20%;
            right: 10%;
            animation-delay: 6s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes float {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 0.7;
            }
            50% {
                transform: translateY(-20px) rotate(180deg);
                opacity: 0.4;
            }
            100% {
                transform: translateY(0) rotate(360deg);
                opacity: 0.7;
            }
        }
        
        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-15px);
            }
        }
        
        @keyframes shake {
            0%, 100% {
                transform: translateX(0);
            }
            10%, 30%, 50%, 70%, 90% {
                transform: translateX(-5px);
            }
            20%, 40%, 60%, 80% {
                transform: translateX(5px);
            }
        }
        
        @media only screen and (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .illustration {
                display: none;
            }
            
            .regform {
                padding: 30px;
            }
            
            .logo {
                font-size: 30px;
            }
            
            #heading {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="regform">
            <div class="floating-icons">
                <i class="fas fa-heart"></i>
                <i class="fas fa-utensils"></i>
                <i class="fas fa-hand-holding-heart"></i>
                <i class="fas fa-seedling"></i>
            </div>
            
            <form action="" method="post">
                <p class="logo">Kind<b>Net</b></p>
                <p id="heading">Welcome back!</p>
                
                <div class="input">
                    <input type="email" placeholder="Email address" name="email" required />
                </div>
                
                <div class="password">
                    <input type="password" placeholder="Password" name="password" id="password" required />
                    <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
                    
                    <?php
                    if($msg == 1){
                        echo '<p class="error">Password does not match.</p>';
                    }
                    ?>
                </div>
                
                <div class="btn">
                    <button type="submit" name="sign">Sign in</button>
                </div>
                
                <div class="signin-up">
                    <p>Don't have an account? <a href="signup.php">Register</a></p>
                </div>
            </form>
        </div>
        
        <div class="illustration">
            <div class="illustration-content">
                <img src="img/login.jpg" alt="Food Donation">
                <h2>Join Our Mission</h2>
                <p>Together we can fight hunger and reduce food waste in our community</p>
            </div>
        </div>
    </div>

    <script>
        // Password visibility toggle
        const showPassword = document.getElementById('showpassword');
        const passwordField = document.getElementById('password');
        
        if (showPassword && passwordField) {
            showPassword.addEventListener('click', function() {
                if(passwordField.type === 'password') {
                    passwordField.type = 'text';
                    showPassword.classList.remove('uil-eye-slash');
                    showPassword.classList.add('uil-eye');
                } else {
                    passwordField.type = 'password';
                    showPassword.classList.remove('uil-eye');
                    showPassword.classList.add('uil-eye-slash');
                }
            });
        }
        
        // Form input animations
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if(this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
        
        // Add floating icons dynamically
        const floatingIcons = document.querySelector('.floating-icons');
        if (floatingIcons) {
            const icons = ['fa-heart', 'fa-utensils', 'fa-hand-holding-heart', 'fa-seedling', 'fa-apple-alt', 'fa-bread-slice'];
            
            for (let i = 0; i < 8; i++) {
                const icon = document.createElement('i');
                icon.className = 'fas ' + icons[Math.floor(Math.random() * icons.length)];
                icon.style.top = Math.random() * 100 + '%';
                icon.style.left = Math.random() * 100 + '%';
                icon.style.animationDelay = Math.random() * 10 + 's';
                icon.style.fontSize = (Math.random() * 10 + 15) + 'px';
                floatingIcons.appendChild(icon);
            }
        }
    </script>
</body>
</html>