<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name'])){
    header("location:login.php");
    exit;
}
?>

<h2>Submit Help Request</h2>
<form action="request_submit.php" method="POST">
    <label>Name:</label><br>
    <input type="text" name="requester_name" required value="<?= $_SESSION['name'] ?>"><br><br>

    <label>Email:</label><br>
    <input type="email" name="email" required value="<?= $_SESSION['email'] ?>"><br><br>

    <label>Phone:</label><br>
    <input type="text" name="phone" required><br><br>

    <label>Type of Help:</label><br>
    <select name="type" required>
        <option value="Student Sponsorship">Student Sponsorship</option>
        <option value="Medical Aid">Medical Aid</option>
        <option value="Disaster Relief">Disaster Relief</option>
        <option value="Other">Other</option>
    </select><br><br>

    <label>Description:</label><br>
    <textarea name="description" rows="4" required></textarea><br><br>

    <label>Amount Needed (optional):</label><br>
    <input type="number" name="amount_needed" step="0.01"><br><br>

    <button type="submit">Submit Request</button>
</form>
