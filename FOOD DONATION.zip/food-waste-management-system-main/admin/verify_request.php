<?php
session_start();
include("../connection.php");

// Admin session check
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../signin.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $request_id = intval($_POST['request_id']);
    $status = $_POST['status'];
    $admin_name = $_SESSION['admin_name']; // save admin name who verified

    $sql = "UPDATE help_requests 
            SET status='$status', admin_verifier='$admin_name', verified_at=NOW() 
            WHERE request_id=$request_id";

    mysqli_query($connection, $sql);
    header("Location: admin_requests.php");
    exit;
}
?>
