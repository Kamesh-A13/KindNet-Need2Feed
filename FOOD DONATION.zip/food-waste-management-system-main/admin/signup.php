<?php
// session_start();
// $connection=mysqli_connect("localhost:3307","root","");
// $db=mysqli_select_db($connection,'demo');
include '../connection.php';
$msg=0;
if(isset($_POST['sign']))
{

    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $location=$_POST['district'];
    $address=$_POST['address'];

    $pass=password_hash($password,PASSWORD_DEFAULT);
    $sql="select * from admin where email='$email'" ;
    $result= mysqli_query($connection, $sql);
    $num=mysqli_num_rows($result);
    if($num==1){
        // echo "<h1> already account is created </h1>";
        // echo '<script type="text/javascript">alert("already Account is created")</script>';
        echo "<h1><center>Account already exists</center></h1>";
    }
    else{
    
    $query="insert into admin(name,email,password,location,address) values('$username','$email','$pass','$location','$address')";
    $query_run= mysqli_query($connection, $query);
    if($query_run)
    {
        // $_SESSION['email']=$email;
        // $_SESSION['name']=$row['name'];
        // $_SESSION['gender']=$row['gender'];
       
        header("location:signin.php");
        // echo "<h1><center>Account does not exists </center></h1>";
        //  echo '<script type="text/javascript">alert("Account created successfully")</script>'; -->
    }
    else{
        echo '<script type="text/javascript">alert("data not saved")</script>';
        
    }
}


   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Admin Registration</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,500;0,700;0,800;1,400;1,600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 500px;
        }
        
        form {
            background: white;
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }
        
        .title {
            font-size: 2.2rem;
            font-weight: 700;
            color: #333;
            display: block;
            text-align: center;
            margin-bottom: 1rem;
            animation: slideDown 0.8s ease;
        }
        
        .input-group {
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        input[type="text"], input[type="email"], input[type="password"], select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
        }
        
        .password {
            position: relative;
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            transition: color 0.3s ease;
        }
        
        .showHidePw:hover {
            color: #06C167;
        }
        
        textarea {
            min-height: 80px;
            resize: vertical;
        }
        
        .input-field {
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        .input-field select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
            cursor: pointer;
        }
        
        .input-field select:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
        }
        
        button {
            width: 100%;
            background: #06C167;
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(6, 193, 103, 0.3);
            margin-top: 1rem;
        }
        
        button:hover {
            background: #059c54;
            transform: translateY(-2px);
            box-shadow: 0 7px 20px rgba(6, 193, 103, 0.4);
        }
        
        .login-signup {
            text-align: center;
            margin-top: 1.5rem;
            animation: fadeInUp 0.8s ease;
        }
        
        .login-signup .text {
            color: #666;
        }
        
        .login-signup .login-link {
            color: #06C167;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .login-signup .login-link:hover {
            text-decoration: underline;
        }
        
        .error {
            color: #e74c3c;
            font-size: 0.9rem;
            margin-top: 5px;
            animation: shake 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @media only screen and (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            form {
                padding: 2rem;
            }
            
            .title {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="post" id="form">
            <span class="title">Admin Registration</span>
            
            <div class="input-group">
                <label for="username">Name</label>
                <input type="text" id="username" name="username" required/>
                <div class="error"></div>
            </div>
            
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required/>
            </div>

            <label class="textlabel" for="password">Password</label> 
            <div class="password">
                <input type="password" name="password" id="password" required/>
                <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
                <?php
                    if($msg==1){
                        echo ' <i class="uil uil-exclamation-circle error-icon"></i>';
                        echo '<p class="error">Password don\'t match.</p>';
                    }
                ?> 
            </div>
            
            <div class="input-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" required></textarea>
            </div>
            
            <div class="input-field">
                <label for="district">Location</label>
                <select id="district" name="district">
                    <option value="chennai">Chennai</option>
                    <option value="kancheepuram">Kancheepuram</option>
                    <option value="thiruvallur">Thiruvallur</option>
                    <option value="vellore">Vellore</option>
                    <option value="tiruvannamalai">Tiruvannamalai</option>
                    <option value="tiruvallur">Tiruvallur</option>
                    <option value="tiruppur">Tiruppur</option>
                    <option value="coimbatore">Coimbatore</option>
                    <option value="erode">Erode</option>
                    <option value="salem">Salem</option>
                    <option value="namakkal">Namakkal</option>
                    <option value="tiruchirappalli">Tiruchirappalli</option>
                    <option value="thanjavur">Thanjavur</option>
                    <option value="pudukkottai">Pudukkottai</option>
                    <option value="karur">Karur</option>
                    <option value="ariyalur">Ariyalur</option>
                    <option value="perambalur">Perambalur</option>
                    <option value="madurai" selected>Madurai</option>
                    <option value="virudhunagar">Virudhunagar</option>
                    <option value="dindigul">Dindigul</option>
                    <option value="ramanathapuram">Ramanathapuram</option>
                    <option value="sivaganga">Sivaganga</option>
                    <option value="thoothukkudi">Thoothukkudi</option>
                    <option value="tirunelveli">Tirunelveli</option>
                    <option value="tiruppur">Tiruppur</option>
                    <option value="tenkasi">Tenkasi</option>
                    <option value="kanniyakumari">Kanniyakumari</option>
                </select> 
            </div>
                  
            <button type="submit" name="sign">Register</button>
            
            <div class="login-signup">
                <span class="text">Already a member?
                    <a href="signin.php" class="text login-link">Login Now</a>
                </span>
            </div>
        </form>
    </div>

    <script>
        // Password visibility toggle
        const showPassword = document.getElementById('showpassword');
        const passwordField = document.getElementById('password');
        
        if (showPassword && passwordField) {
            showPassword.addEventListener('click', function() {
                if(passwordField.type === 'password') {
                    passwordField.type = 'text';
                    showPassword.classList.remove('uil-eye-slash');
                    showPassword.classList.add('uil-eye');
                } else {
                    passwordField.type = 'password';
                    showPassword.classList.remove('uil-eye');
                    showPassword.classList.add('uil-eye-slash');
                }
            });
        }
        
        // Add animation to form elements when they come into view
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        document.querySelectorAll('.input-group, .password, .input-field').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(el);
        });
        
        // Add input focus effects
        const inputs = document.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if(this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
    </script>
</body>
</html>