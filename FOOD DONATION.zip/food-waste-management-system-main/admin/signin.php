<?php
session_start();
// $connection = mysqli_connect("localhost:3307", "root", "");
// $db = mysqli_select_db($connection, 'demo');
include '../connection.php';
$msg=0;
if (isset($_POST['sign'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $sanitized_emailid =  mysqli_real_escape_string($connection, $email);
  $sanitized_password =  mysqli_real_escape_string($connection, $password);
  // $hash=password_hash($password,PASSWORD_DEFAULT);

  $sql = "select * from admin where email='$sanitized_emailid'";
  $result = mysqli_query($connection, $sql);
  $num = mysqli_num_rows($result);
 
  if ($num == 1) {
    while ($row = mysqli_fetch_assoc($result)) {
      if (password_verify($sanitized_password, $row['password'])) {
        $_SESSION['email'] = $email;
        $_SESSION['name'] = $row['name'];
        $_SESSION['location'] = $row['location'];
        $_SESSION['Aid']=$row['Aid'];
        header("location:admin.php");
      } else {
        $msg = 1;
        // echo '<style type="text/css">
        // {
        //     .password input{
                
        //         border:.5px solid red;
                
                
        //       }

        // }
        // </style>';
        // echo "<h1><center> Login Failed incorrect password</center></h1>";
      }
    }
  } else {
    echo "<h1><center>Account does not exists </center></h1>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Admin Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,500;0,700;0,800;1,400;1,600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 450px;
        }
        
        form {
            background: white;
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
            transition: transform 0.3s ease;
        }
        
        form:hover {
            transform: translateY(-5px);
        }
        
        .title {
            font-size: 2.2rem;
            font-weight: 700;
            color: #333;
            display: block;
            text-align: center;
            margin-bottom: 1rem;
            animation: slideDown 0.8s ease;
            position: relative;
        }
        
        .title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 4px;
            background: #06C167;
            border-radius: 2px;
        }
        
        .input-group {
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        input:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
        }
        
        .password {
            position: relative;
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            transition: color 0.3s ease;
            z-index: 2;
        }
        
        .showHidePw:hover {
            color: #06C167;
        }
        
        button {
            width: 100%;
            background: #06C167;
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(6, 193, 103, 0.3);
            margin-top: 1rem;
            position: relative;
            overflow: hidden;
        }
        
        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }
        
        button:hover {
            background: #059c54;
            transform: translateY(-2px);
            box-shadow: 0 7px 20px rgba(6, 193, 103, 0.4);
        }
        
        button:hover::before {
            left: 100%;
        }
        
        .login-signup {
            text-align: center;
            margin-top: 1.5rem;
            animation: fadeInUp 0.8s ease;
        }
        
        .login-signup .text {
            color: #666;
        }
        
        .login-signup .login-link {
            color: #06C167;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .login-signup .login-link:hover {
            text-decoration: underline;
        }
        
        .error {
            color: #e74c3c;
            font-size: 0.9rem;
            margin-top: 5px;
            animation: shake 0.5s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .error-icon {
            font-size: 1rem;
        }
        
        .floating-icons {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        
        .floating-icons i {
            position: absolute;
            color: rgba(6, 193, 103, 0.1);
            font-size: 24px;
            animation: float 15s infinite linear;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @keyframes float {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 0.7;
            }
            50% {
                transform: translateY(-20px) rotate(180deg);
                opacity: 0.4;
            }
            100% {
                transform: translateY(0) rotate(360deg);
                opacity: 0.7;
            }
        }
        
        @media only screen and (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            form {
                padding: 2rem;
            }
            
            .title {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="floating-icons">
        <i class="uil uil-shield-check"></i>
        <i class="uil uil-user-md"></i>
        <i class="uil uil-setting"></i>
        <i class="uil uil-analytics"></i>
    </div>
    
    <div class="container">
        <form action="" id="form" method="post">
            <span class="title">Admin Login</span>
            
            <div class="input-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" required>
                <div class="error"></div>
            </div>
            
            <label class="textlabel" for="password">Password</label>
            <div class="password">
                <input type="password" name="password" id="password" required/>
                <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
                <?php
                    if($msg==1){
                        echo '<i class="uil uil-exclamation-circle error-icon"></i>';
                        echo '<p class="error">Password doesn\'t match.</p>';
                    }
                ?> 
            </div>

            <button type="submit" name="sign">Login</button>
            
            <div class="login-signup">
                <span class="text">Don't have an account?
                    <a href="signup.php" class="text login-link">Register</a>
                </span>
            </div>
        </form>
    </div>

    <script>
        // Password visibility toggle
        const showPassword = document.getElementById('showpassword');
        const passwordField = document.getElementById('password');
        
        if (showPassword && passwordField) {
            showPassword.addEventListener('click', function() {
                if(passwordField.type === 'password') {
                    passwordField.type = 'text';
                    showPassword.classList.remove('uil-eye-slash');
                    showPassword.classList.add('uil-eye');
                } else {
                    passwordField.type = 'password';
                    showPassword.classList.remove('uil-eye');
                    showPassword.classList.add('uil-eye-slash');
                }
            });
        }
        
        // Add animation to form elements when they come into view
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        document.querySelectorAll('.input-group, .password').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(el);
        });
        
        // Add input focus effects
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if(this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
        
        // Add floating icons dynamically
        const floatingIcons = document.querySelector('.floating-icons');
        if (floatingIcons) {
            const icons = ['uil-shield-check', 'uil-user-md', 'uil-setting', 'uil-analytics', 'uil-lock', 'uil-key-skeleton'];
            
            for (let i = 0; i < 6; i++) {
                const icon = document.createElement('i');
                icon.className = 'uil ' + icons[Math.floor(Math.random() * icons.length)];
                icon.style.top = Math.random() * 100 + '%';
                icon.style.left = Math.random() * 100 + '%';
                icon.style.animationDelay = Math.random() * 10 + 's';
                icon.style.fontSize = (Math.random() * 10 + 15) + 'px';
                floatingIcons.appendChild(icon);
            }
        }
    </script>
</body>
</html>