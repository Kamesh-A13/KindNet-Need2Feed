<!-- admin_nav.php -->
<style>
/* ========== NAVBAR STYLING + ANIMATIONS ========== */
nav {
  width: 250px;
  background: #11101d;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  padding: 20px;
  color: #fff;
  transition: width 0.3s ease;
  overflow: hidden;
  z-index: 1000;
}

nav.close {
  width: 80px;
}

nav .logo-name {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 30px;
  transition: opacity 0.3s ease;
}

nav.close .logo-name span {
  opacity: 0;
  pointer-events: none;
}

nav .nav-links li {
  list-style: none;
  margin: 15px 0;
  position: relative;
}

nav .nav-links a {
  color: #fff;
  text-decoration: none;
  display: flex;
  align-items: center;
  padding: 10px;
  border-radius: 8px;
  transition: background 0.3s ease, transform 0.2s ease;
}

nav .nav-links a:hover {
  background: #1d1b31;
  transform: translateX(5px);
}

nav.close .nav-links a span.link-name {
  opacity: 0;
  pointer-events: none;
}

.logout-mode {
  margin-top: auto;
}

.mode {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.mode-toggle {
  width: 40px;
  height: 20px;
  background: #444;
  border-radius: 20px;
  position: relative;
  cursor: pointer;
  transition: background 0.3s ease;
}

.mode-toggle .switch {
  width: 18px;
  height: 18px;
  background: #fff;
  border-radius: 50%;
  position: absolute;
  top: 1px;
  left: 1px;
  transition: left 0.3s ease;
}

body.dark .mode-toggle {
  background: #06C167;
}
body.dark .mode-toggle .switch {
  left: 21px;
}

.dashboard {
  margin-left: 250px;
  transition: margin-left 0.3s ease;
}

nav.close ~ .dashboard {
  margin-left: 80px;
}

/* 3-dot toggle button */
#sidebar-toggle {
  position: fixed;
  top: 15px;
  left: 260px;
  font-size: 24px;
  background: #06C167;
  color: #fff;
  border: none;
  padding: 5px 12px;
  border-radius: 5px;
  cursor: pointer;
  z-index: 1100;
  transition: left 0.3s ease;
}

nav.close ~ #sidebar-toggle {
  left: 90px;
}
</style>

<!-- Sidebar -->
<nav>
  <div class="logo-name">
      <div class="logo-image"></div>
      <span class="logo_name">ADMIN</span>
  </div>

  <div class="menu-items">
      <ul class="nav-links">
          <li><a href="admin.php"><i class="uil uil-estate"></i><span class="link-name">Dashboard</span></a></li>
          <li><a href="admin_requests.php"><i class="uil uil-hands-helping"></i><span class="link-name">Help Requests</span></a></li>
          <li><a href="analytics.php"><i class="uil uil-chart-line"></i><span class="link-name">Analytics</span></a></li>
          <li><a href="admin_donations.php"><i class="uil uil-money-bill"></i><span class="link-name">Donations Received</span></a></li>
          <li><a href="make_request.php"><i class="uil uil-plus-circle"></i><span class="link-name">Add Request</span></a></li>
          <li><a href="donated_items_dashboard.php"><i class="uil uil-box"></i><span class="link-name">Donated Items</span></a></li>
          <li><a href="feedback.php"><i class="uil uil-comments"></i><span class="link-name">Feedbacks</span></a></li>
          <li><a href="adminprofile.php"><i class="uil uil-user-circle"></i><span class="link-name">Profile</span></a></li>
      </ul>

      <ul class="logout-mode">
          <li><a href="../logout.php"><i class="uil uil-signout"></i><span class="link-name">Logout</span></a></li>
          <li class="mode">
              <a href="#"><i class="uil uil-moon"></i><span class="link-name">Dark Mode</span></a>
              <div class="mode-toggle"><span class="switch"></span></div>
          </li>
      </ul>
  </div>
</nav>

<!-- 3-dot toggle button -->
<button id="sidebar-toggle">☰</button>

<script>
// Sidebar toggle with 3-dot button
let sidebar = document.querySelector("nav");
let toggleBtn = document.getElementById("sidebar-toggle");

toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("close");
});

// Dark mode toggle
let modeToggle = document.querySelector(".mode-toggle");
let body = document.querySelector("body");

modeToggle.addEventListener("click", () => {
  body.classList.toggle("dark");
});
</script>
