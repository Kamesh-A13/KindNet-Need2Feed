<?php
// make_request.php
// Place this in the same folder as your existing connect.php

// Include the project's connect file
include_once 'connect.php';

/**
 * Try to locate a mysqli connection object/variable created by connect.php.
 */
function get_mysqli_connection() {
    $candidate_names = [
        'conn','con','link','mysqli','connection','db_conn','dbcon','db'
    ];

    // Check globals for a mysqli object
    foreach ($candidate_names as $name) {
        if (isset($GLOBALS[$name]) && $GLOBALS[$name] instanceof mysqli) {
            return $GLOBALS[$name];
        }
    }

    // If connect.php exposed connection parameters, try them
    if (isset($GLOBALS['servername'], $GLOBALS['username'], $GLOBALS['password'], $GLOBALS['dbname'])) {
        $tmp = mysqli_connect(
            $GLOBALS['servername'],
            $GLOBALS['username'],
            $GLOBALS['password'],
            $GLOBALS['dbname']
        );
        if ($tmp) return $tmp;
    }

    // Fallback: try common local defaults (XAMPP)
    $tries = [
        ['127.0.0.1','root','','demo'],
        ['localhost','root','','demo']
    ];
    
    foreach ($tries as $t) {
        $tmp = mysqli_connect($t[0], $t[1], $t[2], $t[3]);
        if ($tmp) return $tmp;
    }

    return null;
}

$mysqli = get_mysqli_connection();
if (!$mysqli) {
    die("<strong>Database connection failed.</strong><br>
         Please ensure connect.php defines a mysqli connection (commonly as \$conn or \$con),
         or that MySQL is running and the credentials are correct.<br>
         Error: " . mysqli_connect_error());
}

// Check if table exists
$table_check = $mysqli->query("SHOW TABLES LIKE 'help_requests'");
if (!$table_check || $table_check->num_rows == 0) {
    die("<strong>Table 'help_requests' not found.</strong><br>
         Please create the table first with the appropriate structure.");
}
$table_check->free();

// Helper to safely echo sticky form values
function old($key) {
    return isset($_POST[$key]) ? htmlspecialchars($_POST[$key]) : '';
}

$messages = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['requester_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $type        = trim($_POST['type'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $amount_raw  = $_POST['amount_needed'] ?? '';
    
    // Validate and convert amount
    $amount = null;
    if ($amount_raw !== '' && $amount_raw !== null) {
        if (is_numeric($amount_raw)) {
            $amount = floatval($amount_raw);
            if ($amount < 0) {
                $messages[] = "Amount cannot be negative.";
            }
        } else {
            $messages[] = "Amount must be a valid number.";
        }
    }

    // Basic server-side validation
    if (empty($name)) $messages[] = "Name is required.";
    if (empty($email)) {
        $messages[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $messages[] = "Valid email is required.";
    }
    if (empty($phone)) $messages[] = "Phone is required.";
    if (empty($type)) $messages[] = "Type of request is required.";
    if (empty($description)) $messages[] = "Description is required.";

    // Validate field lengths to prevent database errors
    if (strlen($name) > 100) $messages[] = "Name must be less than 100 characters.";
    if (strlen($email) > 100) $messages[] = "Email must be less than 100 characters.";
    if (strlen($phone) > 20) $messages[] = "Phone must be less than 20 characters.";
    if (strlen($type) > 50) $messages[] = "Type must be less than 50 characters.";
    if (strlen($description) > 500) $messages[] = "Description must be less than 500 characters.";

    if (empty($messages)) {
        $success = false;
        
        if ($amount !== null) {
            $sql = "INSERT INTO help_requests (requester_name, email, phone, type, description, amount_needed)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sssssd", $name, $email, $phone, $type, $description, $amount);
                if ($stmt->execute()) {
                    $success = true;
                } else {
                    $messages[] = "Execute failed: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $messages[] = "Prepare failed: " . $mysqli->error;
            }
        } else {
            $sql = "INSERT INTO help_requests (requester_name, email, phone, type, description)
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sssss", $name, $email, $phone, $type, $description);
                if ($stmt->execute()) {
                    $success = true;
                } else {
                    $messages[] = "Execute failed: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $messages[] = "Prepare failed: " . $mysqli->error;
            }
        }

        if ($success) {
            $messages[] = "<span style='color:green;'>✅ Request submitted successfully!</span>";
            // Clear POST to avoid sticky values after success
            $_POST = [];
        }
    }
}

// Close connection at the end
$mysqli->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Make a Help Request</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            max-width: 700px; 
            margin: 20px auto; 
            padding: 20px;
            line-height: 1.6;
        }
        label { 
            display: block; 
            margin-top: 15px; 
            font-weight: bold;
        }
        input[type=text], input[type=email], input[type=number], textarea { 
            width: 100%; 
            padding: 10px; 
            box-sizing: border-box; 
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .messages { 
            margin: 15px 0; 
            padding: 15px; 
            background: #f8f8f8; 
            border-radius: 6px; 
            border-left: 4px solid #007cba;
        }
        .error { color: #d00; }
        .success { color: #008000; }
        button { 
            margin-top: 20px;
            padding: 12px 24px;
            background: #007cba;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #005a87;
        }
        .required { color: red; }
    </style>
</head>
<body>
    <?php include("admin_nav.php"); ?>

    <h2>Submit Help Request</h2>
    

    <?php if (!empty($messages)): ?>
        <div class="messages">
            <?php foreach ($messages as $m): ?>
                <div><?php echo $m; ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <label>Name: <span class="required">*</span>
            <input type="text" name="requester_name" required value="<?php echo old('requester_name'); ?>">
        </label>

        <label>Email: <span class="required">*</span>
            <input type="email" name="email" required value="<?php echo old('email'); ?>">
        </label>

        <label>Phone: <span class="required">*</span>
            <input type="text" name="phone" required value="<?php echo old('phone'); ?>">
        </label>
<label for="type">Type of Request:<span class="required">*</span></label>
<select name="type" id="type" required>
    <option value="" disabled selected>Select a Request Type</option>
    <option value="Health" title="Medical treatments, hospital bills, therapy">Health</option>
    <option value="Education" title="Tuition, books, scholarships, skill development">Education</option>
    <option value="Emergency" title="Natural disasters, accidents, immediate aid">Emergency</option>
    <option value="Community" title="Support for orphanages, old-age homes, sanitation projects">Community</option>
    <option value="Charity" title="Feeding the poor, animal shelters, environmental projects">Charity</option>
</select>



        <label>Description: <span class="required">*</span>
            <textarea name="description" required rows="5"><?php echo old('description'); ?></textarea>
        </label>

        <label>Amount Needed (Optional):
            <input type="number" step="0.01" min="0" name="amount_needed" value="<?php echo old('amount_needed'); ?>">
        </label>

        <button type="submit">Submit Request</button>
    </form>
</body>
</html>