<?php
include("connect.php");

$sql="SELECT * FROM help_requests WHERE status='Verified' ORDER BY verified_at DESC";
$result=mysqli_query($connection,$sql);
?>

<h2>Verified Help Requests / Donations</h2>
<table border="1" cellpadding="5">
<tr>
<th>Name</th>
<th>Type</th>
<th>Description</th>
<th>Quantity</th>
<th>Contact</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>
<td><?= $row['requester_name'] ?></td>
<td><?= $row['type'] ?></td>
<td><?= $row['description'] ?></td>
<td><?= $row['quantity'] ?></td>
<td>Email: <?= $row['email'] ?><br>Phone: <?= $row['phone'] ?></td>
</tr>
<?php } ?>
</table>
