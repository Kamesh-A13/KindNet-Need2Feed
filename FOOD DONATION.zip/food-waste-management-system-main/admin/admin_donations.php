<?php
session_start();
include '../connection.php';

// ------------------------
// Admin session check (add your authentication logic here)
// ------------------------
// if(!isset($_SESSION['admin_id'])) {
//     header("Location: login.php");
//     exit();
// }

// ------------------------
// Fetch all donations
// ------------------------
$sql = "SELECT * FROM donations ORDER BY created_at DESC";
$result = mysqli_query($connection, $sql);

if(!$result){
    die("Database query failed: " . mysqli_error($connection));
}

// Get statistics
$statsQuery = "SELECT 
    COUNT(*) as total_donations,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
    SUM(CASE WHEN status = 'collected' THEN 1 ELSE 0 END) as collected,
    SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled
    FROM donations";
$statsResult = mysqli_query($connection, $statsQuery);
$stats = mysqli_fetch_assoc($statsResult);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Donations Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3a0ca3;
            --success: #4cc9f0;
            --warning: #f8961e;
            --danger: #e63946;
            --info: #560bad;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: var(--dark);
        }
        
        .container {
            max-width: 1800px;
            margin: 0 auto;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-content h1 {
            color: var(--primary);
            margin-bottom: 5px;
            font-size: 2.5rem;
        }
        
        .header-content p {
            color: var(--gray);
            font-size: 1.1rem;
        }
        
        .admin-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary);
            transform: translateY(-2px);
        }
        
        .btn-export {
            background: var(--success);
            color: white;
        }
        
        .btn-export:hover {
            background: #3aa8c9;
            transform: translateY(-2px);
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-left: 4px solid var(--primary);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card.pending { border-left-color: var(--warning); }
        .stat-card.accepted { border-left-color: var(--success); }
        .stat-card.rejected { border-left-color: var(--danger); }
        .stat-card.collected { border-left-color: var(--info); }
        .stat-card.scheduled { border-left-color: var(--primary); }
        
        .stat-number {
            font-size: 2.2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-card.total .stat-number { color: var(--primary); }
        .stat-card.pending .stat-number { color: var(--warning); }
        .stat-card.accepted .stat-number { color: var(--success); }
        .stat-card.rejected .stat-number { color: var(--danger); }
        .stat-card.collected .stat-number { color: var(--info); }
        .stat-card.scheduled .stat-number { color: var(--secondary); }
        
        .stat-label {
            color: var(--gray);
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .controls {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .search-box {
            position: relative;
            flex-grow: 1;
            max-width: 400px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            border-radius: 30px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }
        
        .filter-controls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        select {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: white;
            cursor: pointer;
            min-width: 150px;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1200px;
        }
        
        thead {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
        }
        
        th {
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            position: relative;
            cursor: pointer;
            user-select: none;
        }
        
        th:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        th i {
            margin-left: 5px;
            opacity: 0.7;
        }
        
        tbody tr {
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s ease;
        }
        
        tbody tr:last-child {
            border-bottom: none;
        }
        
        tbody tr:hover {
            background-color: #f1f5ff;
        }
        
        td {
            padding: 12px;
            color: #555;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-accepted { background: #d1edff; color: #0c5460; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .status-collected { background: #d4edda; color: #155724; }
        .status-scheduled { background: #e2e3ff; color: #383d41; }
        
        .pickup-mode {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .pickup-home { background: #e7f3ff; color: #0066cc; }
        .pickup-dropoff { background: #f0f0f0; color: #666; }
        
        .actions {
            display: flex;
            gap: 5px;
        }
        
        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .action-view {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .action-view:hover {
            background: #bbdefb;
        }
        
        .action-edit {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .action-edit:hover {
            background: #e1bee7;
        }
        
        .action-delete {
            background: #ffebee;
            color: #c62828;
        }
        
        .action-delete:hover {
            background: #ffcdd2;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        
        .pagination button {
            padding: 8px 15px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .pagination button:hover {
            background: #f0f0f0;
        }
        
        .pagination button.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        footer {
            text-align: center;
            margin-top: 30px;
            color: var(--gray);
            font-size: 0.9rem;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        tbody tr {
            opacity: 0;
            animation: rowFadeIn 0.5s forwards;
        }
        
        @keyframes rowFadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
            }
            
            .search-box {
                max-width: 100%;
            }
            
            .header-content h1 {
                font-size: 2rem;
            }
            
            .stats-container {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-hand-holding-heart"></i> Donations Management</h1>
                <p>Manage and track all donation requests</p>
            </div>
            <div class="admin-actions">
                <button class="btn btn-primary"><i class="fas fa-plus"></i> Add Donation</button>
                <button class="btn btn-export"><i class="fas fa-file-export"></i> Export Data</button>
            </div>
        </header>
        <?php include("admin_nav.php"); ?>

        
        <div class="stats-container">
            <div class="stat-card total">
                <div class="stat-number"><?= $stats['total_donations'] ?></div>
                <div class="stat-label">Total Donations</div>
            </div>
            <div class="stat-card pending">
                <div class="stat-number"><?= $stats['pending'] ?></div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card accepted">
                <div class="stat-number"><?= $stats['accepted'] ?></div>
                <div class="stat-label">Accepted</div>
            </div>
            <div class="stat-card rejected">
                <div class="stat-number"><?= $stats['rejected'] ?></div>
                <div class="stat-label">Rejected</div>
            </div>
            <div class="stat-card collected">
                <div class="stat-number"><?= $stats['collected'] ?></div>
                <div class="stat-label">Collected</div>
            </div>
            <div class="stat-card scheduled">
                <div class="stat-number"><?= $stats['scheduled'] ?></div>
                <div class="stat-label">Scheduled</div>
            </div>
        </div>
        
        <div class="controls">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" placeholder="Search donations...">
            </div>
            <div class="filter-controls">
                <select id="statusFilter">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="accepted">Accepted</option>
                    <option value="rejected">Rejected</option>
                    <option value="collected">Collected</option>
                    <option value="scheduled">Scheduled</option>
                </select>
                <select id="pickupFilter">
                    <option value="">All Pickup Types</option>
                    <option value="home">Home Pickup</option>
                    <option value="dropoff">Drop-off</option>
                </select>
                <select id="dateFilter">
                    <option value="">Any Date</option>
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                </select>
            </div>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th data-sort="id">ID <i class="fas fa-sort"></i></th>
                        <th data-sort="donor_name">Donor <i class="fas fa-sort"></i></th>
                        <th data-sort="donor_email">Email <i class="fas fa-sort"></i></th>
                        <th data-sort="donor_phone">Phone <i class="fas fa-sort"></i></th>
                        <th>Pickup Mode</th>
                        <th data-sort="pickup_date">Pickup Date <i class="fas fa-sort"></i></th>
                        <th>Address</th>
                        <th data-sort="status">Status <i class="fas fa-sort"></i></th>
                        <th>Remarks</th>
                        <th data-sort="created_at">Created <i class="fas fa-sort"></i></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($result) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><strong><?= htmlspecialchars($row['donor_name']) ?></strong></td>
                            <td><?= htmlspecialchars($row['donor_email']) ?></td>
                            <td><?= htmlspecialchars($row['donor_phone']) ?></td>
                            <td>
                                <span class="pickup-mode pickup-<?= $row['pickup_mode'] === 'home' ? 'home' : 'dropoff' ?>">
                                    <i class="fas fa-<?= $row['pickup_mode'] === 'home' ? 'home' : 'map-marker-alt' ?>"></i>
                                    <?= ucfirst($row['pickup_mode']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if($row['pickup_date']): ?>
                                    <i class="far fa-calendar"></i> <?= $row['pickup_date'] ?><br>
                                    <small><i class="far fa-clock"></i> <?= $row['pickup_time'] ?></small>
                                <?php else: ?>
                                    <em>Not scheduled</em>
                                <?php endif; ?>
                            </td>
                            <td title="<?= htmlspecialchars($row['address']) ?>">
                                <?= strlen($row['address']) > 30 ? substr(htmlspecialchars($row['address']), 0, 30) . '...' : htmlspecialchars($row['address']) ?>
                            </td>
                            <td>
                                <span class="status-badge status-<?= $row['status'] ?>">
                                    <i class="fas fa-<?= getStatusIcon($row['status']) ?>"></i>
                                    <?= ucfirst($row['status']) ?>
                                </span>
                            </td>
                            <td title="<?= htmlspecialchars($row['remarks']) ?>">
                                <?= $row['remarks'] ? (strlen($row['remarks']) > 20 ? substr(htmlspecialchars($row['remarks']), 0, 20) . '...' : htmlspecialchars($row['remarks'])) : '<em>None</em>' ?>
                            </td>
                            <td>
                                <small><i class="far fa-calendar"></i> <?= date('M j, Y', strtotime($row['created_at'])) ?></small><br>
                                <small><i class="far fa-clock"></i> <?= date('g:i A', strtotime($row['created_at'])) ?></small>
                            </td>
                            <td class="actions">
                                <button class="action-btn action-view" onclick="viewDonation(<?= $row['id'] ?>)">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn action-edit" onclick="editDonation(<?= $row['id'] ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn action-delete" onclick="deleteDonation(<?= $row['id'] ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="11" class="no-data">
                                <i class="fas fa-inbox"></i><br>
                                No donations found
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <footer>
            <p>Donation Management System &copy; <?= date('Y') ?> | Admin Panel</p>
        </footer>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchValue) ? '' : 'none';
            });
        });
        
        // Filter functionality
        document.getElementById('statusFilter').addEventListener('change', filterTable);
        document.getElementById('pickupFilter').addEventListener('change', filterTable);
        document.getElementById('dateFilter').addEventListener('change', filterTable);
        
        function filterTable() {
            const statusValue = document.getElementById('statusFilter').value.toLowerCase();
            const pickupValue = document.getElementById('pickupFilter').value.toLowerCase();
            const dateValue = document.getElementById('dateFilter').value;
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const status = row.cells[7].textContent.toLowerCase();
                const pickup = row.cells[4].textContent.toLowerCase();
                const dateText = row.cells[9].textContent.toLowerCase();
                
                const statusMatch = !statusValue || status.includes(statusValue);
                const pickupMatch = !pickupValue || pickup.includes(pickupValue);
                const dateMatch = !dateValue || checkDateMatch(dateText, dateValue);
                
                row.style.display = statusMatch && pickupMatch && dateMatch ? '' : 'none';
            });
        }
        
        function checkDateMatch(dateText, filter) {
            // Simplified date matching - implement based on your needs
            return true;
        }
        
        // Sort functionality
        document.querySelectorAll('th[data-sort]').forEach(header => {
            header.addEventListener('click', function() {
                const column = this.getAttribute('data-sort');
                const isAscending = this.classList.contains('asc');
                sortTable(column, isAscending);
                
                // Update sort indicator
                document.querySelectorAll('th').forEach(th => {
                    th.classList.remove('asc', 'desc');
                });
                
                this.classList.toggle('asc', !isAscending);
                this.classList.toggle('desc', isAscending);
            });
        });
        
        function sortTable(column, ascending) {
            const tbody = document.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {
                const aValue = a.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
                const bValue = b.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
                
                // Handle numeric sorting for ID
                if (column === 'id') {
                    return ascending ? aValue - bValue : bValue - aValue;
                }
                
                // Handle date sorting
                if (column === 'pickup_date' || column === 'created_at') {
                    // You might need to parse dates properly here
                    return ascending ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
                }
                
                // Default text sorting
                return ascending ? 
                    aValue.localeCompare(bValue) : 
                    bValue.localeCompare(aValue);
            });
            
            // Clear and re-append sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
        
        function getColumnIndex(columnName) {
            const headers = Array.from(document.querySelectorAll('th'));
            return headers.findIndex(header => header.getAttribute('data-sort') === columnName) + 1;
        }
        
        // Action functions
        function viewDonation(id) {
            alert('Viewing donation ID: ' + id);
            // Implement view functionality
        }
        
        function editDonation(id) {
            alert('Editing donation ID: ' + id);
            // Implement edit functionality
        }
        
        function deleteDonation(id) {
            if (confirm('Are you sure you want to delete donation #' + id + '?')) {
                alert('Deleting donation ID: ' + id);
                // Implement delete functionality with AJAX
            }
        }
    </script>
</body>
</html>

<?php
// Helper function to get status icons
function getStatusIcon($status) {
    switch($status) {
        case 'pending': return 'clock';
        case 'accepted': return 'check-circle';
        case 'rejected': return 'times-circle';
        case 'collected': return 'shopping-bag';
        case 'scheduled': return 'calendar-check';
        default: return 'question-circle';
    }
}
?>