<?php
session_start();
include("../connection.php");

// Check database connection
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch pending requests
$sql = "SELECT * FROM help_requests WHERE status='Pending' ORDER BY created_at DESC";
$result = mysqli_query($connection, $sql);

// Debug: Check if query failed
if (!$result) {
    die("Database query failed: " . mysqli_error($connection));
}

// Get statistics with error handling
$statsQuery = "SELECT 
    COUNT(*) as total_pending,
    SUM(CASE WHEN type = 'Donation' THEN 1 ELSE 0 END) as donations,
    SUM(CASE WHEN type = 'Request' THEN 1 ELSE 0 END) as requests,
    SUM(CASE WHEN urgency = 'High' THEN 1 ELSE 0 END) as high_urgency
    FROM help_requests WHERE status='Pending'";
    
$statsResult = mysqli_query($connection, $statsQuery);

// Initialize default stats
$stats = [
    'total_pending' => 0,
    'donations' => 0,
    'requests' => 0,
    'high_urgency' => 0
];

if ($statsResult) {
    $stats = mysqli_fetch_assoc($statsResult);
} else {
    // Log error but don't stop execution
    error_log("Statistics query failed: " . mysqli_error($connection));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pending Requests - Admin Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    :root {
        --primary: #4361ee;
        --secondary: #3a0ca3;
        --success: #4cc9f0;
        --warning: #f8961e;
        --danger: #e63946;
        --light: #f8f9fa;
        --dark: #212529;
        --gray: #6c757d;
    }
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
        padding: 20px;
        color: var(--dark);
    }
    
    .container {
        max-width: 1400px;
        margin: 0 auto;
    }
    
    header {
        text-align: center;
        margin-bottom: 30px;
        animation: fadeIn 1s ease;
    }
    
    h1 {
        color: var(--primary);
        margin-bottom: 10px;
        font-size: 2.5rem;
    }
    
    .subtitle {
        color: var(--gray);
        font-size: 1.1rem;
    }
    
    .error-alert {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        border-left: 4px solid #dc3545;
    }
    
    .stats-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border-left: 4px solid var(--warning);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
    }
    
    .stat-card.donations { border-left-color: var(--success); }
    .stat-card.requests { border-left-color: var(--primary); }
    .stat-card.urgency { border-left-color: var(--danger); }
    
    .stat-number {
        font-size: 2.2rem;
        font-weight: bold;
        margin-bottom: 5px;
    }
    
    .stat-card.total .stat-number { color: var(--warning); }
    .stat-card.donations .stat-number { color: var(--success); }
    .stat-card.requests .stat-number { color: var(--primary); }
    .stat-card.urgency .stat-number { color: var(--danger); }
    
    .stat-label {
        color: var(--gray);
        font-size: 0.9rem;
        font-weight: 600;
    }
    
    .controls {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        flex-wrap: wrap;
        gap: 15px;
        background: white;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .search-box {
        position: relative;
        flex-grow: 1;
        max-width: 400px;
    }
    
    .search-box input {
        width: 100%;
        padding: 12px 20px 12px 40px;
        border: 1px solid #ddd;
        border-radius: 30px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    
    .search-box input:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
    }
    
    .search-icon {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray);
    }
    
    .filter-controls {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    
    select {
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background: white;
        cursor: pointer;
        min-width: 150px;
    }
    
    .table-container {
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
        overflow-x: auto;
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
        min-width: 1000px;
    }
    
    thead {
        background: linear-gradient(to right, var(--warning), #e68900);
        color: white;
    }
    
    th {
        padding: 15px 12px;
        text-align: left;
        font-weight: 600;
    }
    
    tbody tr {
        border-bottom: 1px solid #eee;
        transition: background-color 0.3s ease;
    }
    
    tbody tr:last-child {
        border-bottom: none;
    }
    
    tbody tr:hover {
        background-color: #fff9e6;
    }
    
    td {
        padding: 12px;
        color: #555;
        vertical-align: top;
    }
    
    .type-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .type-donation { 
        background: #e3f2fd; 
        color: #1565c0; 
    }
    
    .type-request { 
        background: #f3e5f5; 
        color: #7b1fa2; 
    }
    
    .urgency-badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 0.7rem;
        font-weight: 600;
        margin-top: 5px;
    }
    
    .urgency-high { background: #ffebee; color: #c62828; }
    .urgency-medium { background: #fff3e0; color: #ef6c00; }
    .urgency-low { background: #f3e5f5; color: #7b1fa2; }
    
    .description {
        max-width: 200px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
        position: relative;
    }
    
    .description:hover::after {
        content: attr(data-full);
        position: absolute;
        left: 0;
        top: 100%;
        background: #333;
        color: white;
        padding: 8px;
        border-radius: 4px;
        z-index: 1000;
        white-space: normal;
        width: 300px;
        font-size: 0.9rem;
    }
    
    .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .btn {
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.9rem;
        text-decoration: none;
    }
    
    .btn-verify {
        background: var(--success);
        color: white;
    }
    
    .btn-verify:hover {
        background: #3aa8c9;
        transform: translateY(-2px);
    }
    
    .btn-details {
        background: var(--primary);
        color: white;
    }
    
    .btn-details:hover {
        background: var(--secondary);
        transform: translateY(-2px);
    }
    
    .btn-reject {
        background: var(--danger);
        color: white;
    }
    
    .btn-reject:hover {
        background: #c1121f;
        transform: translateY(-2px);
    }
    
    .no-data {
        text-align: center;
        padding: 40px;
        color: var(--gray);
    }
    
    .no-data i {
        font-size: 3rem;
        margin-bottom: 15px;
        opacity: 0.5;
    }
    
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        animation: fadeIn 0.3s ease;
    }
    
    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 0;
        border-radius: 10px;
        width: 90%;
        max-width: 600px;
        animation: slideIn 0.3s ease;
    }
    
    @keyframes slideIn {
        from { transform: translateY(-50px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
    
    .modal-header {
        background: var(--primary);
        color: white;
        padding: 15px 20px;
        border-radius: 10px 10px 0 0;
        display: flex;
        justify-content: between;
        align-items: center;
    }
    
    .modal-header h3 {
        margin: 0;
    }
    
    .close {
        color: white;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    
    .close:hover {
        color: #ccc;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .detail-row {
        display: flex;
        margin-bottom: 10px;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 5px;
    }
    
    .detail-label {
        font-weight: 600;
        min-width: 120px;
        color: var(--dark);
    }
    
    footer {
        text-align: center;
        margin-top: 30px;
        color: var(--gray);
        font-size: 0.9rem;
    }
    
    /* Animations */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    tbody tr {
        opacity: 0;
        animation: rowFadeIn 0.5s forwards;
    }
    
    @keyframes rowFadeIn {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .controls {
            flex-direction: column;
        }
        
        .search-box {
            max-width: 100%;
        }
        
        h1 {
            font-size: 2rem;
        }
        
        .stats-container {
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        }
        
        .actions {
            flex-direction: column;
        }
        
        .btn {
            justify-content: center;
        }
    }
</style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-clock"></i> Pending Requests</h1>
            <p class="subtitle">Review and verify donation/help requests</p>
        </header>
        <?php include("admin_nav.php"); ?>

        
        <?php
        // Debug information (remove in production)
        if (!$result) {
            echo '<div class="error-alert">';
            echo '<strong>Database Error:</strong> ' . mysqli_error($connection);
            echo '<br><small>Please check if the table "help_requests" exists and has the correct structure.</small>';
            echo '</div>';
        }
        ?>
        
        <div class="stats-container">
            <div class="stat-card total">
                <div class="stat-number"><?= $stats['total_pending'] ?></div>
                <div class="stat-label">Total Pending</div>
            </div>
            <div class="stat-card donations">
                <div class="stat-number"><?= $stats['donations'] ?></div>
                <div class="stat-label">Donation Offers</div>
            </div>
            <div class="stat-card requests">
                <div class="stat-number"><?= $stats['requests'] ?></div>
                <div class="stat-label">Help Requests</div>
            </div>
            <div class="stat-card urgency">
                <div class="stat-number"><?= $stats['high_urgency'] ?></div>
                <div class="stat-label">High Urgency</div>
            </div>
        </div>
        
        <div class="controls">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" placeholder="Search requests...">
            </div>
            <div class="filter-controls">
                <select id="typeFilter">
                    <option value="">All Types</option>
                    <option value="Donation">Donations</option>
                    <option value="Request">Requests</option>
                </select>
                <select id="urgencyFilter">
                    <option value="">All Urgency</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                </select>
            </div>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Urgency</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($row['requester_name']) ?></strong>
                                </td>
                                <td>
                                    <div><i class="fas fa-envelope"></i> <?= htmlspecialchars($row['email']) ?></div>
                                    <div><i class="fas fa-phone"></i> <?= htmlspecialchars($row['phone']) ?></div>
                                </td>
                                <td>
                                    <span class="type-badge type-<?= strtolower($row['type']) ?>">
                                        <i class="fas fa-<?= $row['type'] === 'Donation' ? 'gift' : 'hands-helping' ?>"></i>
                                        <?= htmlspecialchars($row['type']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="description" data-full="<?= htmlspecialchars($row['description']) ?>">
                                        <?= strlen($row['description']) > 50 ? substr(htmlspecialchars($row['description']), 0, 50) . '...' : htmlspecialchars($row['description']) ?>
                                    </div>
                                </td>
                                <td>
                                    <span style="font-weight: 600; color: var(--primary);"><?= htmlspecialchars($row['quantity']) ?></span>
                                </td>
                                <td>
                                    <?php if(isset($row['urgency']) && $row['urgency']): ?>
                                        <span class="urgency-badge urgency-<?= strtolower($row['urgency']) ?>">
                                            <?= htmlspecialchars($row['urgency']) ?>
                                        </span>
                                    <?php else: ?>
                                        <em>Not specified</em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small><?= date('M j, Y', strtotime($row['created_at'])) ?></small><br>
                                    <small><?= date('g:i A', strtotime($row['created_at'])) ?></small>
                                </td>
                                <td>
                                    <div class="actions">
                                        <form method="post" action="verify_request.php" style="display: inline;">
                                            <input type="hidden" name="request_id" value="<?= $row['request_id'] ?>">
                                            <input type="hidden" name="status" value="Verified">
                                            <button type="submit" class="btn btn-verify">
                                                <i class="fas fa-check"></i> Verify
                                            </button>
                                        </form>
                                        <button class="btn btn-details" onclick="showDetails(<?= htmlspecialchars(json_encode($row)) ?>)">
                                            <i class="fas fa-eye"></i> Details
                                        </button>
                                        <button class="btn btn-reject" onclick="rejectRequest(<?= $row['request_id'] ?>)">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="no-data">
                                <i class="fas fa-check-circle"></i><br>
                                <?php 
                                if (!$result) {
                                    echo "Database error occurred. Please check the table structure.";
                                } else {
                                    echo "No pending requests found";
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <footer>
            <p>Request Management System &copy; <?= date('Y') ?> | Admin Panel</p>
        </footer>
    </div>

    <!-- Details Modal -->
    <div id="detailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-info-circle"></i> Request Details</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Details will be inserted here by JavaScript -->
            </div>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchValue) ? '' : 'none';
            });
        });
        
        // Filter functionality
        document.getElementById('typeFilter').addEventListener('change', filterTable);
        document.getElementById('urgencyFilter').addEventListener('change', filterTable);
        
        function filterTable() {
            const typeValue = document.getElementById('typeFilter').value.toLowerCase();
            const urgencyValue = document.getElementById('urgencyFilter').value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const type = row.cells[2].textContent.toLowerCase();
                const urgency = row.cells[5].textContent.toLowerCase();
                
                const typeMatch = !typeValue || type.includes(typeValue);
                const urgencyMatch = !urgencyValue || urgency.includes(urgencyValue);
                
                row.style.display = typeMatch && urgencyMatch ? '' : 'none';
            });
        }
        
        // Modal functionality
        const modal = document.getElementById('detailsModal');
        const closeBtn = document.querySelector('.close');
        
        function showDetails(request) {
            const modalBody = document.getElementById('modalBody');
            modalBody.innerHTML = `
                <div class="detail-row">
                    <span class="detail-label">Request ID:</span>
                    <span>${request.request_id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Name:</span>
                    <span>${request.requester_name}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Email:</span>
                    <span>${request.email}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Phone:</span>
                    <span>${request.phone}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Type:</span>
                    <span>${request.type}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Description:</span>
                    <span>${request.description}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Quantity:</span>
                    <span>${request.quantity}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Urgency:</span>
                    <span>${request.urgency || 'Not specified'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Created:</span>
                    <span>${new Date(request.created_at).toLocaleString()}</span>
                </div>
            `;
            modal.style.display = 'block';
        }
        
        closeBtn.onclick = function() {
            modal.style.display = 'none';
        }
        
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        function rejectRequest(requestId) {
            if (confirm('Are you sure you want to reject this request?')) {
                // You can implement AJAX rejection or form submission here
                alert('Rejecting request ID: ' + requestId);
            }
        }
        
        // Add animation delays for rows
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach((row, index) => {
                row.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html>