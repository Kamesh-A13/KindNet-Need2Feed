<?php
// Include database connection (session already handled there)
include '../connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Donated Items</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: var(--dark);
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        header {
            text-align: center;
            margin-bottom: 30px;
            animation: fadeIn 1s ease;
        }
        
        h1 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 2.5rem;
        }
        
        .subtitle {
            color: var(--gray);
            font-size: 1.1rem;
        }
        
        .stats-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            min-width: 150px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary);
        }
        
        .stat-label {
            color: var(--gray);
            font-size: 0.9rem;
        }
        
        .controls {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .search-box {
            position: relative;
            flex-grow: 1;
            max-width: 400px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            border-radius: 30px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }
        
        .filter-controls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        select {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: white;
            cursor: pointer;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        
        thead {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
        }
        
        th {
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            position: relative;
            cursor: pointer;
            user-select: none;
        }
        
        th:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        th i {
            margin-left: 5px;
            opacity: 0.7;
        }
        
        tbody tr {
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s ease;
        }
        
        tbody tr:last-child {
            border-bottom: none;
        }
        
        tbody tr:hover {
            background-color: #f1f5ff;
        }
        
        td {
            padding: 12px;
            color: #555;
        }
        
        .category-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .category-clothing { background: #e0f7fa; color: #006064; }
        .category-food { background: #f3e5f5; color: #4a148c; }
        .category-furniture { background: #e8f5e9; color: #1b5e20; }
        .category-electronics { background: #fff3e0; color: #e65100; }
        .category-books { background: #fce4ec; color: #880e4f; }
        .category-other { background: #f5f5f5; color: #424242; }
        
        .condition-new { color: #2e7d32; font-weight: 600; }
        .condition-used { color: #f9a825; font-weight: 600; }
        .condition-refurbished { color: #1565c0; font-weight: 600; }
        
        .actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .btn-view {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .btn-view:hover {
            background: #bbdefb;
        }
        
        .btn-edit {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .btn-edit:hover {
            background: #e1bee7;
        }
        
        .btn-delete {
            background: #ffebee;
            color: #c62828;
        }
        
        .btn-delete:hover {
            background: #ffcdd2;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        
        .pagination button {
            padding: 8px 15px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .pagination button:hover {
            background: #f0f0f0;
        }
        
        .pagination button.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        footer {
            text-align: center;
            margin-top: 30px;
            color: var(--gray);
            font-size: 0.9rem;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes tableFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        tbody tr {
            opacity: 0;
            animation: rowFadeIn 0.5s forwards;
        }
        
        @keyframes rowFadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
            }
            
            .search-box {
                max-width: 100%;
            }
            
            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-hands-helping"></i> All Donated Items</h1>
            <p class="subtitle">Manage and view all donation records</p>
        </header>
        <?php include("admin_nav.php"); ?>

        
        <?php
        // Get statistics
        $totalQuery = "SELECT COUNT(*) as total FROM item_donations";
        $totalResult = mysqli_query($connection, $totalQuery);
        $totalRow = mysqli_fetch_assoc($totalResult);
        $totalItems = $totalRow['total'];
        
        $todayQuery = "SELECT COUNT(*) as today FROM item_donations WHERE DATE(date) = CURDATE()";
        $todayResult = mysqli_query($connection, $todayQuery);
        $todayRow = mysqli_fetch_assoc($todayResult);
        $todayItems = $todayRow['today'];
        
        $categoriesQuery = "SELECT COUNT(DISTINCT category) as categories FROM item_donations";
        $categoriesResult = mysqli_query($connection, $categoriesQuery);
        $categoriesRow = mysqli_fetch_assoc($categoriesResult);
        $totalCategories = $categoriesRow['categories'];
        ?>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-number"><?php echo $totalItems; ?></div>
                <div class="stat-label">Total Donations</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $todayItems; ?></div>
                <div class="stat-label">Today's Donations</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $totalCategories; ?></div>
                <div class="stat-label">Categories</div>
            </div>
        </div>
        
        <div class="controls">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" placeholder="Search donations...">
            </div>
            <div class="filter-controls">
                <select id="categoryFilter">
                    <option value="">All Categories</option>
                    <?php
                    $catQuery = "SELECT DISTINCT category FROM item_donations ORDER BY category";
                    $catResult = mysqli_query($connection, $catQuery);
                    while($catRow = mysqli_fetch_assoc($catResult)) {
                        echo "<option value='".$catRow['category']."'>".$catRow['category']."</option>";
                    }
                    ?>
                </select>
                <select id="conditionFilter">
                    <option value="">All Conditions</option>
                    <option value="New">New</option>
                    <option value="Used">Used</option>
                    <option value="Refurbished">Refurbished</option>
                </select>
            </div>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th data-sort="Id">ID <i class="fas fa-sort"></i></th>
                        <th data-sort="donor_name">Donor Name <i class="fas fa-sort"></i></th>
                        <th data-sort="donor_email">Email <i class="fas fa-sort"></i></th>
                        <th data-sort="item_name">Item Name <i class="fas fa-sort"></i></th>
                        <th data-sort="category">Category <i class="fas fa-sort"></i></th>
                        <th data-sort="quantity">Quantity <i class="fas fa-sort"></i></th>
                        <th data-sort="condition">Condition <i class="fas fa-sort"></i></th>
                        <th data-sort="date">Date <i class="fas fa-sort"></i></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM item_donations ORDER BY Id DESC";
                    $result = mysqli_query($connection, $query);

                    if ($result && mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                            // Determine category badge class
                            $categoryClass = "category-other";
                            if ($row['category'] == 'Clothing') $categoryClass = "category-clothing";
                            elseif ($row['category'] == 'Food') $categoryClass = "category-food";
                            elseif ($row['category'] == 'Furniture') $categoryClass = "category-furniture";
                            elseif ($row['category'] == 'Electronics') $categoryClass = "category-electronics";
                            elseif ($row['category'] == 'Books') $categoryClass = "category-books";
                            
                            // Determine condition class
                            $conditionClass = "condition-used";
                            if ($row['condition'] == 'New') $conditionClass = "condition-new";
                            elseif ($row['condition'] == 'Refurbished') $conditionClass = "condition-refurbished";
                            
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['Id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['donor_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['donor_email']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['item_name']) . "</td>";
                            echo "<td><span class='category-badge $categoryClass'>" . htmlspecialchars($row['category']) . "</span></td>";
                            echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                            echo "<td class='$conditionClass'>" . htmlspecialchars($row['condition']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                            echo "<td class='actions'>";
                            echo "<button class='btn btn-view' onclick='viewItem(" . $row['Id'] . ")'><i class='fas fa-eye'></i> View</button>";
                            echo "<button class='btn btn-edit' onclick='editItem(" . $row['Id'] . ")'><i class='fas fa-edit'></i> Edit</button>";
                            echo "<button class='btn btn-delete' onclick='deleteItem(" . $row['Id'] . ")'><i class='fas fa-trash'></i> Delete</button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9' class='no-data'><i class='fas fa-inbox'></i><br>No donated items found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <footer>
            <p>Donation Management System &copy; <?php echo date('Y'); ?></p>
        </footer>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchValue) ? '' : 'none';
            });
        });
        
        // Filter functionality
        document.getElementById('categoryFilter').addEventListener('change', filterTable);
        document.getElementById('conditionFilter').addEventListener('change', filterTable);
        
        function filterTable() {
            const categoryValue = document.getElementById('categoryFilter').value.toLowerCase();
            const conditionValue = document.getElementById('conditionFilter').value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const category = row.cells[4].textContent.toLowerCase();
                const condition = row.cells[6].textContent.toLowerCase();
                
                const categoryMatch = categoryValue === '' || category === categoryValue;
                const conditionMatch = conditionValue === '' || condition === conditionValue;
                
                row.style.display = categoryMatch && conditionMatch ? '' : 'none';
            });
        }
        
        // Sort functionality
        document.querySelectorAll('th[data-sort]').forEach(header => {
            header.addEventListener('click', function() {
                const column = this.getAttribute('data-sort');
                const isAscending = this.classList.contains('asc');
                sortTable(column, isAscending);
                
                // Update sort indicator
                document.querySelectorAll('th').forEach(th => {
                    th.classList.remove('asc', 'desc');
                });
                
                this.classList.toggle('asc', !isAscending);
                this.classList.toggle('desc', isAscending);
            });
        });
        
        function sortTable(column, ascending) {
            const tbody = document.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {
                const aValue = a.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
                const bValue = b.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
                
                // Handle numeric sorting for ID and Quantity
                if (column === 'Id' || column === 'quantity') {
                    return ascending ? aValue - bValue : bValue - aValue;
                }
                
                // Handle date sorting
                if (column === 'date') {
                    return ascending ? 
                        new Date(aValue) - new Date(bValue) : 
                        new Date(bValue) - new Date(aValue);
                }
                
                // Default text sorting
                return ascending ? 
                    aValue.localeCompare(bValue) : 
                    bValue.localeCompare(aValue);
            });
            
            // Clear and re-append sorted rows
            rows.forEach(row => tbody.appendChild(row));
        }
        
        function getColumnIndex(columnName) {
            const headers = Array.from(document.querySelectorAll('th'));
            return headers.findIndex(header => header.getAttribute('data-sort') === columnName) + 1;
        }
        
        // Action functions (placeholder - implement as needed)
        function viewItem(id) {
            alert('Viewing item with ID: ' + id);
            // Implement view functionality
        }
        
        function editItem(id) {
            alert('Editing item with ID: ' + id);
            // Implement edit functionality
        }
        
        function deleteItem(id) {
            if (confirm('Are you sure you want to delete this donation record?')) {
                alert('Deleting item with ID: ' + id);
                // Implement delete functionality
            }
        }
    </script>
</body>
</html>