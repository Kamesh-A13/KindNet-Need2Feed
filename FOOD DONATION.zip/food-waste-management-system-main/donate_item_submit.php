<?php
session_start();
require_once "connection.php"; // provides $connection

// Check connection variable
if (!isset($connection) || !($connection instanceof mysqli)) {
    $_SESSION['error'] = "Database connection error. Please ensure connection.php exists and sets \$connection (mysqli).";
    header("Location: donate_item.php");
    exit;
}

// CSRF check
if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error'] = "Invalid form submission (CSRF). Please try again.";
    header("Location: donate_item.php");
    exit;
}

// Gather + sanitize POST data
$donor_name  = trim($_POST['donor_name'] ?? '');
$donor_email = trim($_POST['donor_email'] ?? '');
$donor_phone = trim($_POST['donor_phone'] ?? '');
$item_name   = trim($_POST['item_name'] ?? '');
$category    = trim($_POST['category'] ?? 'other');
$quantity    = intval($_POST['quantity'] ?? 1);
$condition   = trim($_POST['condition'] ?? 'good');
$address     = trim($_POST['address'] ?? '');
$location    = trim($_POST['location'] ?? '');

// Basic validation
$errors = [];
if ($donor_name === '') $errors[] = "Your name is required.";
if ($donor_phone === '') $errors[] = "Phone is required.";
if ($item_name === '') $errors[] = "Item name is required.";
if ($address === '') $errors[] = "Address is required.";
if ($location === '') $errors[] = "Location is required.";
if ($donor_email !== '' && !filter_var($donor_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email address.";
if ($quantity < 1) $quantity = 1;

if (!empty($errors)) {
    $_SESSION['error'] = implode(' ', $errors);
    header("Location: donate_item.php");
    exit;
}

// Prepare and execute insert (use prepared statements)
$sql = "INSERT INTO item_donations 
    (donor_name, donor_email, donor_phone, item_name, category, quantity, `condition`, address, location) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $connection->prepare($sql);
if (!$stmt) {
    $_SESSION['error'] = "Database error (prepare): " . $connection->error;
    header("Location: donate_item.php");
    exit;
}

$stmt->bind_param(
    "sssssisss",
    $donor_name,
    $donor_email,
    $donor_phone,
    $item_name,
    $category,
    $quantity,
    $condition,
    $address,
    $location
);

if ($stmt->execute()) {
    $_SESSION['success'] = "Thank you! Your donation has been recorded.";
} else {
    $_SESSION['error'] = "Database error (execute): " . $stmt->error;
}

$stmt->close();
header("Location: donate_item.php");
exit;
?>
