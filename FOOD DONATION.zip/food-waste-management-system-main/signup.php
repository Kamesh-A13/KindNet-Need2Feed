<?php
include 'connection.php';
if(isset($_POST['sign']))
{
    $username=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $gender=$_POST['gender'];

    $pass=password_hash($password,PASSWORD_DEFAULT);
    $sql="select * from login where email='$email'" ;
    $result= mysqli_query($connection, $sql);
    $num=mysqli_num_rows($result);
    if($num==1){
        echo "<h1><center>Account already exists</center></h1>";
    }
    else{
        $query="insert into login(name,email,password,gender) values('$username','$email','$pass','$gender')";
        $query_run= mysqli_query($connection, $query);
        if($query_run)
        {
            header("location:signin.php");
        }
        else{
            echo '<script type="text/javascript">alert("data not saved")</script>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Food Donate</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,500;0,700;0,800;1,400;1,600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            display: flex;
            max-width: 1200px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 1s ease-out;
        }
        
        .regform {
            flex: 1;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .right {
            flex: 1;
            background: linear-gradient(135deg, #06C167 0%, #059c54 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
        }
        
        .right::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
            animation: float 20s infinite linear;
        }
        
        .right img {
            max-width: 80%;
            z-index: 1;
            position: relative;
            animation: bounce 5s infinite ease-in-out;
        }
        
        .logo {
            font-size: 36px;
            text-align: center;
            margin-bottom: 10px;
            animation: slideDown 0.8s ease-out;
        }
        
        .logo b {
            color: #06C167;
        }
        
        #heading {
            font-size: 28px;
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            animation: slideUp 0.8s ease-out 0.3s both;
        }
        
        .input, .password {
            margin-bottom: 20px;
            position: relative;
            animation: fadeIn 1s ease-out 0.5s both;
        }
        
        .textlabel {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e1e1;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        input:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
        }
        
        .password {
            position: relative;
        }
        
        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            transition: color 0.3s ease;
        }
        
        .showHidePw:hover {
            color: #06C167;
        }
        
        .radio {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            animation: fadeIn 1s ease-out 0.7s both;
        }
        
        .radio input[type="radio"] {
            display: none;
        }
        
        .radio label {
            padding: 10px 20px;
            border: 2px solid #e1e1e1;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .radio label::before {
            content: '';
            width: 18px;
            height: 18px;
            border: 2px solid #e1e1e1;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .radio input[type="radio"]:checked + label {
            border-color: #06C167;
            background: rgba(6, 193, 103, 0.1);
        }
        
        .radio input[type="radio"]:checked + label::before {
            border-color: #06C167;
            background: #06C167;
            box-shadow: inset 0 0 0 3px white;
        }
        
        .btn {
            margin-bottom: 20px;
            animation: fadeIn 1s ease-out 0.9s both;
        }
        
        button {
            width: 100%;
            padding: 15px;
            background: #06C167;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(6, 193, 103, 0.3);
        }
        
        button:hover {
            background: #059c54;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(6, 193, 103, 0.4);
        }
        
        .signin-up {
            text-align: center;
            animation: fadeIn 1s ease-out 1.1s both;
        }
        
        .signin-up a {
            color: #06C167;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .signin-up a:hover {
            text-decoration: underline;
            letter-spacing: 0.5px;
        }
        
        .floating-icons {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        
        .floating-icons i {
            position: absolute;
            color: rgba(6, 193, 103, 0.1);
            font-size: 24px;
            animation: float 15s infinite linear;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes float {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 0.7;
            }
            50% {
                transform: translateY(-20px) rotate(180deg);
                opacity: 0.4;
            }
            100% {
                transform: translateY(0) rotate(360deg);
                opacity: 0.7;
            }
        }
        
        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-20px);
            }
        }
        
        @media only screen and (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .right {
                display: none;
            }
            
            .regform {
                padding: 30px;
            }
            
            .logo {
                font-size: 30px;
            }
            
            #heading {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="floating-icons">
        <i class="fas fa-heart"></i>
        <i class="fas fa-utensils"></i>
        <i class="fas fa-hand-holding-heart"></i>
        <i class="fas fa-seedling"></i>
    </div>
    
    <div class="container">
        <div class="regform">
            <form action="" method="post">
                <p class="logo">Kind<b>Net</b></p>
                <p id="heading">Create your account</p>
                
                <div class="input">
                    <label class="textlabel" for="name">User name</label>
                    <input type="text" id="name" name="name" required/>
                </div>
                
                <div class="input">
                    <label class="textlabel" for="email">Email</label>
                    <input type="email" id="email" name="email" required/>
                </div>
                
                <div class="password">
                    <label class="textlabel" for="password">Password</label>
                    <input type="password" name="password" id="password" required/>
                    <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
                </div>
                
                <div class="radio">
                    <input type="radio" name="gender" id="male" value="male" required/>
                    <label for="male">Male</label>
                    
                    <input type="radio" name="gender" id="female" value="female" required/>
                    <label for="female">Female</label>
                </div>
                
                <div class="btn">
                    <button type="submit" name="sign">Continue</button>
                </div>
                
                <div class="signin-up">
                    <p>Already have an account? <a href="signin.php">Sign in</a></p>
                </div>
            </form>
        </div>
        
        <div class="right">
              <img src="img/login.jpg" alt="Food Donation">
        </div>
    </div>

    <script>
        // Password visibility toggle
        const showPassword = document.getElementById('showpassword');
        const passwordField = document.getElementById('password');
        
        showPassword.addEventListener('click', function() {
            if(passwordField.type === 'password') {
                passwordField.type = 'text';
                showPassword.classList.remove('uil-eye-slash');
                showPassword.classList.add('uil-eye');
            } else {
                passwordField.type = 'password';
                showPassword.classList.remove('uil-eye');
                showPassword.classList.add('uil-eye-slash');
            }
        });
        
        // Form input animations
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if(this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
    </script>
</body>
</html>