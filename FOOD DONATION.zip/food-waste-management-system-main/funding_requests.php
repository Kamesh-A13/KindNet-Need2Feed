<?php
include("connection.php"); // Database connection

// Fetch all verified help requests
$sql = "SELECT * FROM help_requests WHERE status='Verified' ORDER BY verified_at DESC";
$result = mysqli_query($connection, $sql);

// Handle DB query error
if(!$result){
    die("Database query failed: " . mysqli_error($connection));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verified Help / Funding Requests - KINDNET</title>
<link rel="stylesheet" href="home.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
.header { text-align: center; padding: 30px 0; background: #06C167; color: #fff; }
.header h1 { margin: 0; }
.funding-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; width: 90%; margin: 30px auto; }
.funding-card { border: 1px solid #ccc; border-radius: 10px; padding: 20px; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
.funding-card h3 { color: #06C167; margin-top: 0; }
.funding-card p { margin: 8px 0; }
.donate-btn { display: inline-block; padding: 8px 12px; background: #06C167; color: #fff; text-decoration: none; border-radius: 5px; margin-top: 10px; }
.donate-btn:hover { background: #049955; }
.no-requests { text-align: center; font-size: 18px; margin-top: 30px; }
</style>
</head>
<body>

<div class="header">
    <h1>Verified Help / Funding Requests</h1>
    <p>Support verified requests and make a difference today!</p>
</div>

<div class="funding-container">
    <?php if(mysqli_num_rows($result) > 0): ?>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
            <div class="funding-card">
                <h3><?= htmlspecialchars($row['requester_name']) ?> (<?= htmlspecialchars($row['type']) ?>)</h3>
                <p><strong>Description:</strong> <?= htmlspecialchars($row['description']) ?></p>
                <?php if(!empty($row['amount_needed'])): ?>
                    <p><strong>Amount Needed:</strong> ₹<?= number_format($row['amount_needed'],2) ?></p>
                <?php endif; ?>
                <p><strong>Contact:</strong> Email: <?= htmlspecialchars($row['email']) ?> | Phone: <?= htmlspecialchars($row['phone']) ?></p>
                <a class="donate-btn" href="donate_funding.php?request_id=<?= intval($row['request_id']) ?>">Donate Now</a>

            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="no-requests">No verified help requests available at the moment.</p>
    <?php endif; ?>
</div>

</body>
</html>
