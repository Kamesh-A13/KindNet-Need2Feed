<?php
session_start();
include("connection.php");

// Check request_id in GET
if(!isset($_GET['request_id'])){
    die("Invalid request.");
}

$request_id = intval($_GET['request_id']);

// Fetch request details + admin info
$sql = "SELECT * FROM help_requests WHERE request_id = $request_id AND status='Verified'";
$result = mysqli_query($connection, $sql);

if(!$result || mysqli_num_rows($result) == 0){
    die("Request not found or not verified.");
}

$request = mysqli_fetch_assoc($result);

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $donor_name = mysqli_real_escape_string($connection, $_POST['donor_name']);
    $donor_email = mysqli_real_escape_string($connection, $_POST['donor_email']);
    $donor_phone = mysqli_real_escape_string($connection, $_POST['donor_phone']);
    $amount = floatval($_POST['amount']);

    $admin_name = $request['admin_verifier'];
    
    // Fetch admin email
    $admin_sql = "SELECT email FROM admin WHERE name='".mysqli_real_escape_string($connection, $admin_name)."' LIMIT 1";
    $admin_res = mysqli_query($connection, $admin_sql);
    $admin_email = mysqli_fetch_assoc($admin_res)['email'] ?? '';

    $insert_sql = "INSERT INTO funding_donations 
        (request_id, donor_name, donor_email, donor_phone, amount, admin_name, admin_email)
        VALUES ('$request_id','$donor_name','$donor_email','$donor_phone','$amount','$admin_name','$admin_email')";

    if(mysqli_query($connection, $insert_sql)){
        echo "<p style='color:green;'>Thank you for your donation! Admin ($admin_name) has been notified.</p>";
    } else {
        echo "<p style='color:red;'>Error: " . mysqli_error($connection) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Donate for <?= htmlspecialchars($request['requester_name']) ?></title>
<link rel="stylesheet" href="home.css">
</head>
<body>

<h2>Donate for <?= htmlspecialchars($request['requester_name']) ?> (<?= htmlspecialchars($request['type']) ?>)</h2>
<p><strong>Description:</strong> <?= htmlspecialchars($request['description']) ?></p>
<p><strong>Amount Needed:</strong> ₹<?= number_format($request['amount_needed'],2) ?></p>
<p><strong>Verified by Admin:</strong> <?= htmlspecialchars($request['admin_verifier']) ?></p>

<form method="post">
    <label>Your Name:</label><br>
    <input type="text" name="donor_name" required><br><br>

    <label>Your Email:</label><br>
    <input type="email" name="donor_email" required><br><br>

    <label>Your Phone:</label><br>
    <input type="text" name="donor_phone"><br><br>

    <label>Amount to Donate:</label><br>
    <input type="number" name="amount" min="1" step="0.01" required><br><br>

    <button type="submit">Donate</button>
</form>

</body>
</html>
