<?php
// donate_item.php
session_start();

// Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf = $_SESSION['csrf_token'];

// Grab flash messages
$success = $_SESSION['success'] ?? null;
$error   = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate Items - Food Donate</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,500;0,700;0,800;1,400;1,600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            line-height: 1.6;
            min-height: 100vh;
        }
        
        header {
            background: linear-gradient(135deg, #06C167 0%, #059c54 100%);
            color: white;
            padding: 1rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .logo {
            font-size: 2.2rem;
            font-weight: 700;
        }
        
        .logo b {
            color: white;
        }
        
        .nav-bar ul {
            display: flex;
            list-style: none;
        }
        
        .nav-bar ul li {
            margin-left: 2rem;
        }
        
        .nav-bar ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 5px 10px;
            border-radius: 5px;
        }
        
        .nav-bar ul li a:hover, .nav-bar ul li a.active {
            background: rgba(255,255,255,0.2);
        }
        
        .hamburger {
            display: none;
            cursor: pointer;
        }
        
        .hamburger .line {
            width: 25px;
            height: 3px;
            background: white;
            margin: 5px;
            transition: all 0.3s ease;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('img/BANNER.jpg');
            background-size: cover;
            background-position: center;
            height: 40vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding-top: 80px;
            margin-bottom: 3rem;
        }
        
        .hero-content h1 {
            font-size: 3rem;
            color: white;
            margin-bottom: 1rem;
            animation: fadeInDown 1s ease;
        }
        
        .hero-content p {
            font-size: 1.3rem;
            color: #f0f0f0;
            max-width: 800px;
            animation: fadeInUp 1s ease;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 5% 4rem;
        }
        
        .flash {
            max-width: 100%;
            margin: 10px auto;
            padding: 15px 20px;
            border-radius: 8px;
            text-align: center;
            font-weight: 500;
            animation: slideIn 0.5s ease;
        }
        
        .flash.success {
            background: #e6fff0;
            color: #0b7a3a;
            border: 1px solid #bff0c9;
            box-shadow: 0 4px 12px rgba(11, 122, 58, 0.1);
        }
        
        .flash.error {
            background: #fff0f0;
            color: #a10b0b;
            border: 1px solid #f0bfbf;
            box-shadow: 0 4px 12px rgba(161, 11, 11, 0.1);
        }
        
        .donation-form {
            background: white;
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-top: 2rem;
            animation: fadeIn 1s ease;
            transition: transform 0.3s ease;
        }
        
        .donation-form:hover {
            transform: translateY(-5px);
        }
        
        .donation-form h2 {
            text-align: center;
            margin: 0 0 1.5rem;
            color: #06C167;
            font-size: 2.2rem;
            position: relative;
            padding-bottom: 10px;
        }
        
        .donation-form h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: #06C167;
            border-radius: 2px;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            animation: fadeInUp 0.5s ease;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #06C167;
            box-shadow: 0 0 0 3px rgba(6, 193, 103, 0.2);
            outline: none;
            transform: translateY(-2px);
        }
        
        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .submit-btn {
            width: 100%;
            background: #06C167;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(6, 193, 103, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }
        
        .submit-btn:hover {
            background: #059c54;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(6, 193, 103, 0.4);
        }
        
        .submit-btn:hover::before {
            left: 100%;
        }
        
        .small {
            font-size: 0.9rem;
            color: #666;
            margin-top: 10px;
            text-align: center;
        }
        
        .required::after {
            content: ' *';
            color: #e74c3c;
        }
        
        .donation-steps {
            display: flex;
            justify-content: space-between;
            margin: 2rem 0;
            flex-wrap: wrap;
        }
        
        .step {
            flex: 1;
            min-width: 200px;
            text-align: center;
            padding: 1.5rem;
            margin: 0.5rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .step:hover {
            transform: translateY(-5px);
        }
        
        .step-icon {
            width: 70px;
            height: 70px;
            background: #06C167;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 1.8rem;
        }
        
        .step h3 {
            color: #06C167;
            margin-bottom: 0.5rem;
        }
        
        footer {
            background: #222;
            color: white;
            padding: 3rem 10% 1rem;
            margin-top: 4rem;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .footer-about h3, .footer-contact h3, .footer-links h3 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            color: #06C167;
        }
        
        .footer-about p {
            line-height: 1.8;
            color: #bbb;
        }
        
        .footer-contact p {
            margin-bottom: 1rem;
            color: #bbb;
        }
        
        .footer-contact a {
            color: #06C167;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-contact a:hover {
            text-decoration: underline;
        }
        
        .footer-links ul {
            list-style: none;
        }
        
        .footer-links ul li {
            margin-bottom: 0.8rem;
        }
        
        .footer-links ul li a {
            color: #bbb;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-links ul li a:hover {
            color: #06C167;
            padding-left: 5px;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid #444;
            color: #bbb;
            font-size: 0.9rem;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @media only screen and (max-width: 768px) {
            .hamburger {
                display: block;
            }
            
            .nav-bar {
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: #06C167;
                clip-path: polygon(0 0, 100% 0, 100% 0, 0 0);
                transition: all 0.5s ease;
            }
            
            .nav-bar.active {
                clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
            }
            
            .nav-bar ul {
                flex-direction: column;
                padding: 1rem 0;
            }
            
            .nav-bar ul li {
                margin: 0;
                text-align: center;
                padding: 1rem 0;
            }
            
            .hero-content h1 {
                font-size: 2.2rem;
            }
            
            .hero-content p {
                font-size: 1.1rem;
            }
            
            .donation-form {
                padding: 2rem;
            }
            
            .donation-steps {
                flex-direction: column;
            }
            
            .step {
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">KindNet</b></div>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="nav-bar">
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="donate_item.php" class="active">Donate Items</a></li>
                <li><a href="profile.php">Profile</a></li>
            </ul>
        </nav>
    </header>
    
    <section class="hero-section">
        <div class="hero-content">
            <h1>Donate Items</h1>
            <p>Your generosity can make a difference. Donate clothes, books, and toys to those in need.</p>
        </div>
    </section>
    
    <div class="container">
        <?php if ($success): ?>
            <div class="flash success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="flash error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="donation-steps">
            <div class="step">
                <div class="step-icon">
                    <i class="fa fa-edit"></i>
                </div>
                <h3>Fill Form</h3>
                <p>Provide details about your donation</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fa fa-check-circle"></i>
                </div>
                <h3>Submit</h3>
                <p>Review and submit your donation</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fa fa-truck"></i>
                </div>
                <h3>We Collect</h3>
                <p>We'll arrange pickup of your items</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fa fa-heart"></i>
                </div>
                <h3>Help Others</h3>
                <p>Your donation reaches those in need</p>
            </div>
        </div>
        
        <div class="donation-form">
            <form action="donate_item_submit.php" method="post" novalidate>
                <h2>Donate Clothes / Books / Toys</h2>
                
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                
                <div class="form-group">
                    <label for="donor_name" class="required">Your name</label>
                    <input id="donor_name" name="donor_name" type="text" maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="donor_email">Email</label>
                    <input id="donor_email" name="donor_email" type="email" maxlength="100">
                </div>
                
                <div class="form-group">
                    <label for="donor_phone" class="required">Phone</label>
                    <input id="donor_phone" name="donor_phone" type="text" maxlength="25" required>
                </div>
                
                <div class="form-group">
                    <label for="item_name" class="required">Item name (e.g., 5 T-shirts)</label>
                    <input id="item_name" name="item_name" type="text" maxlength="150" required>
                </div>
                
                <div class="form-group">
                    <label for="category" class="required">Category</label>
                    <select id="category" name="category" required>
                        <option value="clothes">Clothes</option>
                        <option value="books">Books</option>
                        <option value="toys">Toys</option>
                        <option value="shoes">Shoes</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input id="quantity" name="quantity" type="number" min="1" value="1">
                </div>
                
                <div class="form-group">
                    <label for="condition">Condition</label>
                    <select id="condition" name="condition">
                        <option value="good">Good</option>
                        <option value="new">New</option>
                        <option value="usable">Usable</option>
                        <option value="repair_needed">Repair Needed</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="address" class="required">Address</label>
                    <textarea id="address" name="address" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="location" class="required">Location</label>
                    <input id="location" name="location" type="text" maxlength="50" required>
                </div>
                
                <button type="submit" class="submit-btn">Submit Donation</button>
                <div class="small">Fields marked * are required.</div>
            </form>
        </div>
    </div>
    
    <footer>
        <div class="footer-content">
            <div class="footer-about">
                <h3>About Us</h3>
                <p>Food Donate is a platform dedicated to reducing waste and fighting need by connecting donors with those who can benefit from their generosity.</p>
            </div>
            <div class="footer-contact">
                <h3>Contact</h3>
                <p><i class="fa fa-map-marker"></i> Sathyabama University, Chennai</p>
                <p><i class="fa fa-phone"></i> +91 98765 43210</p>
                <p><i class="fa fa-envelope"></i> <a href="mailto:contact@fooddonate.org">contact@fooddonate.org</a></p>
            </div>
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="home.html">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="donate_item.php">Donate Items</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Food Donate. All rights reserved.</p>
        </div>
    </footer>

    <script>
        hamburger = document.querySelector(".hamburger");
        hamburger.onclick = function() {
            navBar = document.querySelector(".nav-bar");
            navBar.classList.toggle("active");
        }
        
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.style.padding = '0.5rem 5%';
                header.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
            } else {
                header.style.padding = '1rem 5%';
                header.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
            }
        });
        
        // Add animation to form elements when they come into view
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        document.querySelectorAll('.form-group, .step').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(el);
        });
        
        // Add input focus effects
        const inputs = document.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if(this.value === '') {
                    this.parentElement.classList.remove('focused');
                }
            });
        });
    </script>
</body>
</html>