<?php
include("connection.php"); // your DB connection

// Fetch only verified requests
$sql = "SELECT * FROM help_requests WHERE status='Verified' ORDER BY verified_at DESC";
$result = mysqli_query($connection, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Help Requests / Funding Dashboard</title>
<link rel="stylesheet" href="home.css">
<style>
.container { width: 90%; margin: auto; margin-top: 30px; }
.card { border: 1px solid #ccc; padding: 20px; margin-bottom: 20px; border-radius: 8px; background: #f9f9f9; }
.card h3 { margin: 0 0 10px; }
.card p { margin: 5px 0; }
.donate-btn { background: #28a745; color: #fff; padding: 8px 12px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; }
.donate-btn:hover { background: #218838; }
</style>
</head>
<body>

<h2 style="text-align:center;">Verified Help Requests / Funding</h2>
<div class="container">

<?php if(mysqli_num_rows($result) > 0): ?>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
        <div class="card">
            <h3><?= htmlspecialchars($row['requester_name']) ?> (<?= htmlspecialchars($row['type']) ?>)</h3>
            <p><strong>Description:</strong> <?= htmlspecialchars($row['description']) ?></p>
            <p><strong>Amount Needed:</strong> ₹<?= number_format($row['amount_needed'], 2) ?></p>
            <p><strong>Contact:</strong> Email: <?= htmlspecialchars($row['email']) ?> | Phone: <?= htmlspecialchars($row['phone']) ?></p>
            <a class="donate-btn" href="donate_funding.php?request_id=<?= intval($row['request_id']) ?>">Donate Now</a>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p style="text-align:center;">No verified requests available at the moment.</p>
<?php endif; ?>

</div>
</body>
</html>
